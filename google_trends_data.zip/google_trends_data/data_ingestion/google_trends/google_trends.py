from pytrends.request import TrendReq
import pandas as pd
import datetime
import time

# Initialize Google Trends API
pytrends = TrendReq()

# Define the keyword list (the reduced version)
words = [
    # Daily Essentials
    "hand sanitizer", "face mask", "toothpaste", "soap", "laundry detergent", "toilet paper", "deodorant",
    "shampoo", "conditioner", "mouthwash", "dish soap", "sponges", "trash bags", "paper towels",

    # Electronics
    "smartphone", "laptop", "headphones", "television", "camera", "microwave", "vacuum cleaner",
    "tablet", "smartwatch", "gaming console", "wireless earbuds", "e-reader", "projector", "router", "power bank",

    # Fashion
    "sneakers", "jacket", "backpack", "jeans", "t-shirt", "watch", "sunglasses", "boots",
    "dresses", "scarves", "hats", "leggings", "gloves", "belts", "wallets", "handbags",

    # Food and Beverage
    "coffee beans", "energy drinks", "chocolate", "bottled water", "vitamins", "pasta", "olive oil", "bread",
    "tea", "protein powder", "cereal", "snacks", "fruit juice", "honey", "organic vegetables", "cheese",

    # Health and Fitness
    "yoga mat", "dumbbells", "exercise bike", "fitness tracker", "water bottle", "jump rope", "treadmill",
    "resistance bands", "foam roller", "pull-up bar", "kettlebells", "sports shoes", "sports bra", "gym bag",

    # Furniture and Decor
    "sofa", "dining table", "mattress", "desk", "lamp", "bed frame", "coffee table", "blanket",
    "area rug", "bookshelf", "wardrobe", "dining chairs", "throw pillows", "mirror", "curtains", "wall art",

    # Beauty and Skincare
    "foundation", "mascara", "lipstick", "nail polish", "face serum", "sunscreen", "makeup remover", "hair serum",
    "face mask (skincare)", "body lotion", "eye cream", "blush", "highlighter", "makeup brushes", "toner", "facial cleanser",

    # Baby Products
    "diapers", "baby wipes", "baby formula", "stroller", "baby monitor", "pacifier", "crib", "infant car seat",
    "baby clothes", "baby shampoo", "high chair", "baby carrier", "changing table", "baby toys", "baby thermometer",

    # Pet Supplies
    "dog food", "cat food", "pet bed", "dog leash", "cat litter", "pet shampoo", "dog treats", "pet carrier",
    "pet toys", "aquarium", "pet vitamins", "pet grooming tools", "pet training pads", "pet clothes", "pet bowls",

    # DIY and Tools
    "hammer", "screwdriver", "drill", "toolbox", "paintbrush", "ladder", "work gloves", "pliers",
    "saw", "wrench", "measuring tape", "nails", "sandpaper", "electric saw", "paint roller", "tape measure",

    # Books and Stationery
    "notebook", "pen", "printer paper", "stapler", "scissors", "calculator", "desk organizer", "calendar",
    "book light", "journals", "sticky notes", "highlighters", "fountain pen", "file folder", "whiteboard markers",

    # Seasonal Keywords
    "Christmas decorations", "Halloween costumes", "summer dresses", "winter coat", "swimsuit", "Thanksgiving turkey",
    "Easter eggs", "Valentine's gifts", "New Year's fireworks", "snow shovel", "picnic basket", "beach umbrella",

    # Other Popular Products
    "wireless charger", "portable charger", "air purifier", "hair dryer", "slow cooker", "instant pot",
    "robot vacuum", "electric kettle", "space heater", "smart doorbell", "electric toothbrush", "noise-canceling headphones"
]



# Set date range: January 1, 2023, to today's date
start_date = "2023-01-01"
end_date = datetime.datetime.now().strftime("%Y-%m-%d")

# Split keywords into smaller batches to avoid API restrictions
batch_size = 5
data_frames = []

for i in range(0, len(words), batch_size):
    keyword_batch = words[i:i + batch_size]
    try:
        pytrends.build_payload(keyword_batch, timeframe=f'{start_date} {end_date}')
        df = pytrends.interest_over_time()
        time.sleep(5)
        if not df.empty:
            # Remove the 'isPartial' column if it exists
            df = df.drop(columns=['isPartial'], errors='ignore')
            data_frames.append(df)
        print(str(i) + 'finished')
    except:
        print("hit limitation")
        time.sleep(600)

if data_frames:
    combined_df = pd.concat(data_frames, axis=1)
    combined_df.to_csv("google_trends_data_2022.csv")
    print("Data saved as google_trends_data.csv")
else:
    print("No data was retrieved.")
