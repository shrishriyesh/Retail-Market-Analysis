import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object GoogleTrendsDataCleaning {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Google Trends Data Cleaning")
      .getOrCreate()

    val inputFile = "/user/ky2591_nyu_edu/loudacre/project/data_ingestion/google_trends_data.csv"
    val outputFile = "/user/ky2591_nyu_edu/loudacre/project/data_ingestion/ETL_google_trends_data"

    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv(inputFile)

    val cleanedDF = df.na.drop()

    val columns = df.columns.filterNot(_.equals("date"))
    val filteredDF = columns.foldLeft(cleanedDF) { (acc, colName) =>
      acc.filter(col(colName).between(0, 100))
    }

    filteredDF.write
      .option("header", "true")
      .csv(outputFile)

    spark.stop()
  }
}
