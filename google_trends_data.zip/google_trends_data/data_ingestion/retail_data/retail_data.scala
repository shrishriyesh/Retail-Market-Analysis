import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

object retailData {
    def main(args: Array[String]) {
    if (args.length < 0) {
        System.err.println("")
        System.exit(1)
    }

    val sc = new SparkContext()

    val retail = sc.textFile("/user/ky2591_nyu_edu/loudacre/project/data_ingestion/retail_data.csv")
                    .map(line => {
                        val n = line.split(",")
                        (n(6), n(7), n(9), n(14), n(15), n(16), n(17), n(21), n(22), n(23), n(28), n(29))
                    })
                    .filter(line => line.productIterator.forall {
                        case s: String => s.nonEmpty
                        case _ => true
                    })
                    .filter(line => line._5 == "Year" || line._5.toInt >= 2019)
                    .filter(line => line._4 == "Date" || line._4.contains("/") && line._4.split("/").length == 3)
                    .map(line => {
                        if (line._4 == "Date") {
                            Seq(line._1, line._2, line._3, line._4, line._5, line._6, line._7, line._8, line._9, line._10, line._11, line._12)
                        .mkString(",")
                        } else {
                            val formattedDate = if (line._4.split("/")(2).length == 4) {
                            val temp = line._4.split("/")
                            temp(2) + "/" + temp(0) + "/" + temp(1)
                        } else {
                            line._4
                        }
                        Seq(line._1, line._2, line._3, formattedDate, line._5, line._6, line._7, line._8, line._9, line._10, line._11, line._12)
                        .mkString(",")
                        }
                    })


    retail.coalesce(1).saveAsTextFile("/user/ky2591_nyu_edu/loudacre/project/data_ingestion/ETL_retail_data");

    sc.stop()
    }
}