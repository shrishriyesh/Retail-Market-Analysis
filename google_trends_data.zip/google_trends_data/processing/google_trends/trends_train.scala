import org.apache.spark.sql.SparkSession
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.regression.DecisionTreeRegressor
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.types._
import org.apache.spark.sql.Row

object TrendsPrediction {
  def main(args: Array[String]): Unit = {
    // Create a SparkSession
    val spark = SparkSession.builder()
      .appName("TrendsPrediction")
      .getOrCreate()

    // Read the data from the CSV file
    val ds = spark.read.option("header", "true").csv("loudacre/project/processing/ETL_google_trends_data.csv")

    // Feature engineering: Extract year, month, and day from the date
    val newDs = ds.withColumn("year", col("date").substr(1, 4).cast("int"))
      .withColumn("month", col("date").substr(6, 2).cast("int"))
      .withColumn("day", col("date").substr(9, 2).cast("int"))

    // Define a function to categorize the month into a season
    def f_season(m: Int): Int = {
      if (m == 1 || m == 11 || m == 12) {
        4  // Winter
      } else if (m == 2 || m == 3 || m == 4) {
        1  // Spring
      } else if (m == 5 || m == 6 || m == 7) {
        2  // Summer
      } else {
        3  // Fall
      }
    }

    // Register the season function as a UDF
    val f_season_udf: UserDefinedFunction = udf((m: Int) => f_season(m))

    // Add the season feature using the UDF
    val newDs2 = newDs.withColumn("season", f_season_udf(col("month").cast("int")))

    // Define a function to mark holidays
    val isHoliday = when(
      // Christmas and New Year
      (col("month") === 1 && col("day") <= 7) ||
      (col("month") === 12 && col("day") >= 18) ||

      // Thanksgiving and Black Friday
      (col("month") === 11 && col("day") >= 20) ||

      // Veteran's Day
      (col("month") === 11 && col("day") === 11) ||

      // Valentine's Day
      (col("month") === 2 && col("day") >= 7 && col("day") <= 14) ||

      // Easter
      ((col("month") === 3 && col("day") >= 20) ||
      (col("month") === 4 && col("day") <= 20)) ||

      // Mother's Day
      (col("month") === 5 && col("day") <= 14),
    1
    ).otherwise(0)

    // Add the holiday feature
    val newDs3 = newDs2.withColumn("is_holiday", isHoliday)

    // Add day of the week and weekend features
    val newDs4 = newDs3.withColumn("day_of_week", dayofweek(col("date")))
      .withColumn("is_weekend", when(col("day_of_week") === 1 || col("day_of_week") === 7, 1).otherwise(0))

    // Add seasonal sine and cosine features based on the day of the year
    val newDs5 = newDs4.withColumn("day_of_year", dayofyear(col("date")))
      .withColumn("sin_season", sin(lit(2 * math.Pi) * col("day_of_year") / lit(365)))
      .withColumn("cos_season", cos(lit(2 * math.Pi) * col("day_of_year") / lit(365)))
      .drop("day_of_year")

    // Prepare the data for machine learning
    val tempData = newDs5.drop("date")

    // Cast all columns to double type for ML model
    val rawData = tempData.select(tempData.columns.map {
      colName => col(colName).cast("double").as(colName)
    }: _*)

    // Define feature columns
    val featureCols = Array("year", "month", "day", "season", "is_holiday", "day_of_week", "is_weekend", "cos_season", "sin_season")

    // Assemble the features into a single vector column
    val assembler = new VectorAssembler()
      .setInputCols(featureCols)
      .setOutputCol("features")

    // Transform the raw data
    val data = assembler.transform(rawData)

    // Split data into training and testing sets
    val Array(trainingData, testData) = data.randomSplit(Array(0.8, 0.2), seed = 1234L)

    // Define the product keywords
    val keywordLabels = Array(
  "hand sanitizer", "face mask", "toothpaste", "soap", "laundry detergent", "toilet paper", "deodorant", 
  "shampoo", "conditioner", "mouthwash", "dish soap", "sponges", "trash bags", "paper towels", "smartphone", 
  "laptop", "headphones", "television", "camera", "microwave", "vacuum cleaner", "tablet", "smartwatch", 
  "gaming console", "wireless earbuds", "e-reader", "projector", "router", "power bank", "sneakers", "leggings", 
  "gloves", "belts", "wallets", "handbags", "pasta", "olive oil", "bread", "tea", "protein powder", "cereal", 
  "snacks", "fruit juice", "honey", "organic vegetables", "cheese", "yoga mat", "dumbbells", "exercise bike", 
  "fitness tracker", "water bottle", "jump rope", "treadmill", "resistance bands", "foam roller", "sofa", 
  "dining table", "mattress", "desk", "lamp", "wardrobe", "dining chairs", "throw pillows", "mirror", "curtains", 
  "wall art", "foundation", "mascara", "lipstick", "nail polish", "face serum", "sunscreen", "makeup remover", 
  "hair serum", "face mask (skincare)", "body lotion", "eye cream", "blush", "highlighter", "makeup brushes", 
  "stroller", "baby monitor", "pacifier", "crib", "infant car seat", "baby clothes", "baby shampoo", "high chair", 
  "baby carrier", "changing table", "baby toys", "baby thermometer", "dog food", "cat food", "pet bed", "dog leash", 
  "cat litter", "pet shampoo", "dog treats", "pet carrier", "pet toys", "aquarium", "pet vitamins", "pet grooming tools", 
  "pet training pads", "pet clothes", "pet bowls", "hammer", "screwdriver", "drill", "toolbox", "paintbrush", "ladder", 
  "work gloves", "pliers", "saw", "wrench", "measuring tape", "nails", "sandpaper", "electric saw", "paint roller", 
  "tape measure", "notebook", "pen", "printer paper", "stapler", "scissors", "calculator", "desk organizer", 
  "calendar", "book light", "journals", "sticky notes", "highlighters", "fountain pen", "file folder", "whiteboard markers", 
  "Christmas decorations", "Halloween costumes", "summer dresses", "winter coat", "swimsuit", "Thanksgiving turkey", 
  "Easter eggs", "Valentine's gifts", "New Year's fireworks", "snow shovel", "picnic basket", "beach umbrella", 
  "wireless charger", "portable charger", "air purifier", "hair dryer", "slow cooker", "instant pot", "robot vacuum", 
  "electric kettle", "space heater", "smart doorbell", "electric toothbrush", "noise-canceling headphones"
  )

    val schema = StructType(Seq(
      StructField("date", DateType, true)
      ))

    val temp = Seq(Row(java.sql.Date.valueOf("2024-12-31")))

    val predictionData = spark.createDataFrame(
      spark.sparkContext.parallelize(temp), 
      schema
    )

    val predictionDs = predictionData.withColumn("year", col("date").substr(1, 4).cast("int"))
            .withColumn("month", col("date").substr(6, 2).cast("int"))
            .withColumn("day", col("date").substr(9, 2).cast("int"))

    val newDsWithFeatures2 = predictionDs.withColumn("season", f_season_udf(col("month").cast("int")))
                             .withColumn("is_holiday", isHoliday)
                             .withColumn("day_of_week", dayofweek(col("date")))
                             .withColumn("is_weekend", when(col("day_of_week") === 1 || col("day_of_week") === 7, 1).otherwise(0))
                             .withColumn("day_of_year", dayofyear(col("date")))
                             .withColumn("sin_season", sin(lit(2 * math.Pi) * col("day_of_year") / lit(365)))
                             .withColumn("cos_season", cos(lit(2 * math.Pi) * col("day_of_year") / lit(365)))
                             .drop("day_of_year")

    val assembler2 = new VectorAssembler()
    .setInputCols(Array("year", "month", "day", "season", "is_holiday", "day_of_week", "is_weekend", "cos_season", "sin_season"))
    .setOutputCol("features")

    val newDataWithFeatures2 = assembler.transform(newDsWithFeatures2)


    // Train and evaluate the model for each product label
    keywordLabels.foreach { label =>
      val dt = new DecisionTreeRegressor()
        .setLabelCol(label)
        .setFeaturesCol("features")

      // Train the model
      val model = dt.fit(trainingData)

      // Make predictions
      val predictions = model.transform(testData)

      // Evaluate the model using RMSE
      val evaluator = new RegressionEvaluator()
        .setLabelCol(label)
        .setPredictionCol("prediction")
        .setMetricName("rmse")

      // Compute the RMSE for the current product
      val rmse = evaluator.evaluate(predictions)
      println(s"Root Mean Squared Error (RMSE) for $label = $rmse")

      val results = model.transform(newDataWithFeatures2)

      results.select("date", "prediction").show()

    }

    // Stop the Spark session
    spark.stop()
  }
}
